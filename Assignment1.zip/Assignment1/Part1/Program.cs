﻿

namespace Assignment1;

class Program
{
    static void Main(string[] args)
    {
        Pet pet = new Pet();
        pet.Start();

        Album album = new Album();
        album.Start();

        TicketSeller ticket = new TicketSeller();
        ticket.Start();


       
    }
}



