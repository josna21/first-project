﻿namespace Part2;
class Program
{
    static void Main(string[] args)
    {
        //Calling the Start method from Phone.cs
        Phone cellphone = new Phone();
        cellphone.Start();

    }
}

